/** Automatically generated file. DO NOT MODIFY */
package com.daneshzaki.thingse;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}