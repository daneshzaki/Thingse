package com.daneshzaki.thingse;



import android.app.ActionBar;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.view.MenuItem;

//This class is used to display and store the preferences 
public class Preferences extends PreferenceActivity 
{
		//this method loads the preferences from the XML file
        @SuppressWarnings("deprecation")
		@Override
        protected void onCreate(Bundle savedInstanceState) 
        {
                super.onCreate(savedInstanceState);
                addPreferencesFromResource(R.xml.preferences);
                ActionBar actionBar = getActionBar();
                actionBar.setHomeButtonEnabled(true);
                actionBar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP|ActionBar.DISPLAY_SHOW_HOME|ActionBar.DISPLAY_USE_LOGO);
                
        }
        
        //show previous activity
    	@Override
    	public boolean onOptionsItemSelected(MenuItem menuItem)
    	{		
        	//sending back to the prev activity
    		finish();
    		return true;
    	}        
        

}